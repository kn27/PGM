gibbs.py is the module I created to support the homework.

Please open the ipynb notebook, this is where part 1 of the homework is done. The html file is just in case you can't open the jupyter notebook for some reason. 
